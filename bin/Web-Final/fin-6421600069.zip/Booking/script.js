function saveData() {
  const name = document.getElementById("name");
  const date = document.getElementById("date");
  const time = document.getElementById("time");
  const countSeat = document.getElementById("countSeat");
  localStorage.setItem(
    "info_seat",
    JSON.stringify({
      name: name.value,
      date: date.value,
      time: time.value,
      countSeat: countSeat.value,
    })
  );
  document.getElementById("name").value = "";
  document.getElementById("date").value = "";
  document.getElementById("time").value = "";
  document.getElementById("countSeat").value = "";
  loadData();
  alert("Data saved 🫡");
}

function loadData() {
  const container = document.getElementById("data");
  container.innerHTML = "";
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    const value = localStorage.getItem(key);
    console.log(value);
    const x = JSON.parse(value);
    const div = document.createElement("div");
    div.textContent = `Name: ${x.name} , Date: ${x.date} , Time: ${x.time} , Seat: ${x.countSeat}`;
    const removeButton = document.createElement("button");
    removeButton.textContent = "Remove";
    removeButton.onclick = function () {
      localStorage.removeItem(key);
      loadData();
    };
    const editButton = document.createElement("button");
    editButton.textContent = "edit";
    editButton.onclick = function () {
      localStorage.getItem(key);
      const x = JSON.parse(value);
      document.getElementById("name").value = x.name;
      document.getElementById("date").value = x.date;
      document.getElementById("time").value = x.time;
      document.getElementById("countSeat").value = x.countSeat;
      loadData();
    };


    div.appendChild(removeButton);
    div.appendChild(editButton);
    container.appendChild(div);
  }
}
document.addEventListener("DOMContentLoaded", () => {
  loadData();
});
